import { createAsyncThunk } from "@reduxjs/toolkit"
 import axios from "axios"
//  console.log("hello");
 export const getUserAction= createAsyncThunk("get/user", async (logindata, {rejectWithValue,getState})=>{
     try {
        console.log("hello sir");
        const { data  } = await axios.get("https://602e7c2c4410730017c50b9d.mockapi.io/users", logindata)
        console.log(data);
        
        // if (data) {
        //     localStorage.setItem("register", JSON.stringify(data))
        //     return data
        // } else {
            
        //     return data ? data : rejectWithValue("email or password wrong")
        // }
      
        return data
        
    } catch (error) {
        rejectWithValue(error)
    }
})