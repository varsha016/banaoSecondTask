import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { getUserAction } from '../redux/userAction'






const Home = () => {
    const [data, setdata] = useState()
    const [open, setOpen] = useState(false);
    const [isToggled, setIsToggled] = useState(false)
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);
    const { allUsers } = useSelector(state => state.users)
    const dispatch = useDispatch()
    useEffect(() => {

        dispatch(getUserAction())

    }, [])
    const handleToggle = () => {
        setIsToggled(!isToggled)
    };
    return (<>
        <pre>{JSON.stringify(data, null, 2)}</pre>
        <div className='bg'>
            <div className="container mt-5 ">
                <div className='row'>
                    {!allUsers ? <div className="spinner-border " role="status">
                        <span className="visually-hidden">Loading...</span>
                    </div> : ""}

                    <div className="col-sm-6">

                        <div className="card">
                            <strong className="card-header fs-2 text-center text-success">USER DETAILS</strong>
                            {allUsers?.map(item => <div className="card-body" onClick={e => {
                                handleToggle()
                                setdata(item)
                            }} >
                                <span className='' >
                                    <img src={item.avatar} alt="userImg" width={100} height={100} className='img-fluid rounded-circle' />
                                    <strong className='ms-5'>{item.profile.firstName} {item.profile.lastName}</strong>
                                    {/* <h1 >{item.id} </h1> */}


                                </span>
                            </div>

                            )}
                        </div>

                    </div>
                    <div className="col-sm-6 bg-success">
                        {isToggled && <div className="card mt-2">
                            <div className="card-header text-center fs-2 text-success">
                                <strong>User Details</strong>

                            </div>
                            <div className="card-body">
                                <div className=' d-flex justify-content-between'>
                                    <div className='text-center'>
                                        <img src={data.avatar} alt="Img" className='img-fluid rounded-circle' />
                                        <p>
                                            <strong className='mt-4'>{data.profile.username}</strong>

                                        </p>
                                    </div>
                                    <div className='ps-4'>

                                        <h5>Bio:- {data.Bio}</h5>
                                        <h5>FullName:- {data.profile.firstName} {data.profile.lastName}</h5>
                                        <h5>Email:- {data.profile.email}</h5>


                                    </div>
                                </div>

                            </div>
                        </div>}


                    </div>

                </div>

            </div>
        </div>


    </>
    )
}

export default Home






